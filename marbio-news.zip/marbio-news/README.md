# Marbio News — Déploiement Vercel

## Structure
```
marbio-news/
├── api/
│   └── refresh.js      ← endpoint Tavily (appelé par le cron + le frontend)
├── public/
│   └── index.html      ← le site
├── vercel.json         ← config cron 7h00 UTC
└── package.json
```

## Déploiement (10 minutes)

### 1. Mettre le projet sur GitHub
- Crée un repo GitHub (github.com → New repository)
- Upload les fichiers ou utilise Git

### 2. Connecter à Vercel
- Va sur vercel.com → New Project
- Importe ton repo GitHub
- Framework Preset : **Other**
- Root Directory : laisser vide
- Clique **Deploy**

### 3. Ajouter les clés API (IMPORTANT)
Dans Vercel → ton projet → Settings → Environment Variables :

| Name | Value |
|------|-------|
| `TAVILY_API_KEY` | ta clé Tavily (app.tavily.com) |

Clique **Save** puis **Redeploy**.

### 4. Vérifier le cron
- Vercel → ton projet → Settings → Crons
- Tu verras `/api/refresh` schedulé à `0 7 * * *` (7h00 UTC = 8h00 Suisse été / 7h00 hiver)

## Utilisation
- Le site charge automatiquement les news au démarrage
- Le cron actualise toutes les catégories chaque matin à 7h
- Les résultats sont mis en cache 1 heure (s-maxage=3600)

## Coût estimé
- Vercel Hobby : gratuit
- Tavily : ~6 recherches/jour × 30 = 180 req/mois (gratuit sous 1000/mois)
